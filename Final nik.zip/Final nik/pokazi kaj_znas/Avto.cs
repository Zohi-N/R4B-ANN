﻿using System;

namespace pokazi_kaj_znas  // ← TVOJ NAMESPACE!
{
    // ═══════════════════════════════════════════════════════════════════════
    // AVTO - tip vozila (deduje od Vozilo)
    // ═══════════════════════════════════════════════════════════════════════
    // OOP KONCEPTI:
    // ✅ DEDOVANJE - deduje vse od Vozilo
    // ✅ POLIMORFIZEM - override IzracunajCeno() z SVOJO logiko
    // ✅ BASE - kliče konstruktor starša
    // ═══════════════════════════════════════════════════════════════════════

    public class Avto : Vozilo
    {
        // KONSTRUKTOR - kliče konstruktor od Vozilo
        public Avto(string lastnik) : base(lastnik)
        {
        }


        // OVERRIDE - implementacija abstract metode
        // POLIMORFIZEM: Ko kličeš vozilo.IzracunajCeno() in je Avto,
        // se pokliče TA metoda
        public override decimal IzracunajCeno()
        {
            // Cena: 2€ na uro za avto
            TimeSpan cas = DateTime.Now - Ura;
            int ure = (int)Math.Ceiling(cas.TotalHours);
            return ure * 2m;
        }
    }
}
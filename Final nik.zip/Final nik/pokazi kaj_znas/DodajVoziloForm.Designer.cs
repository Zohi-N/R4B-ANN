﻿namespace pokazi_kaj_znas  // ← TVOJ NAMESPACE!
{
    partial class DodajVoziloForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtLastnik = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rbAvto = new System.Windows.Forms.RadioButton();
            this.rbMotor = new System.Windows.Forms.RadioButton();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnPreklici = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(30, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dodajanje novega vozila";
            // 
            // txtLastnik
            // 
            this.txtLastnik.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtLastnik.Location = new System.Drawing.Point(35, 110);
            this.txtLastnik.Name = "txtLastnik";
            this.txtLastnik.Size = new System.Drawing.Size(330, 28);
            this.txtLastnik.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(35, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Lastnik vozila:";
            // 
            // rbAvto
            // 
            this.rbAvto.AutoSize = true;
            this.rbAvto.Checked = true;
            this.rbAvto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbAvto.Location = new System.Drawing.Point(20, 30);
            this.rbAvto.Name = "rbAvto";
            this.rbAvto.Size = new System.Drawing.Size(144, 24);
            this.rbAvto.TabIndex = 3;
            this.rbAvto.TabStop = true;
            this.rbAvto.Text = "🚗 Avto (2€/h)";
            this.rbAvto.UseVisualStyleBackColor = true;
            // 
            // rbMotor
            // 
            this.rbMotor.AutoSize = true;
            this.rbMotor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbMotor.Location = new System.Drawing.Point(20, 65);
            this.rbMotor.Name = "rbMotor";
            this.rbMotor.Size = new System.Drawing.Size(152, 24);
            this.rbMotor.TabIndex = 4;
            this.rbMotor.Text = "🏍️ Motor (1€/h)";
            this.rbMotor.UseVisualStyleBackColor = true;
            // 
            // btnDodaj
            // 
            this.btnDodaj.BackColor = System.Drawing.Color.LimeGreen;
            this.btnDodaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.btnDodaj.ForeColor = System.Drawing.Color.White;
            this.btnDodaj.Location = new System.Drawing.Point(35, 310);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(150, 45);
            this.btnDodaj.TabIndex = 5;
            this.btnDodaj.Text = "✅ Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = false;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnPreklici
            // 
            this.btnPreklici.BackColor = System.Drawing.Color.Gray;
            this.btnPreklici.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.btnPreklici.ForeColor = System.Drawing.Color.White;
            this.btnPreklici.Location = new System.Drawing.Point(215, 310);
            this.btnPreklici.Name = "btnPreklici";
            this.btnPreklici.Size = new System.Drawing.Size(150, 45);
            this.btnPreklici.TabIndex = 6;
            this.btnPreklici.Text = "❌ Prekliči";
            this.btnPreklici.UseVisualStyleBackColor = false;
            this.btnPreklici.Click += new System.EventHandler(this.btnPreklici_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbAvto);
            this.groupBox1.Controls.Add(this.rbMotor);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.groupBox1.Location = new System.Drawing.Point(35, 170);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 110);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tip vozila";
            // 
            // DodajVoziloForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 380);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnPreklici);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtLastnik);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DodajVoziloForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Dodaj novo vozilo";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLastnik;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbAvto;
        private System.Windows.Forms.RadioButton rbMotor;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnPreklici;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
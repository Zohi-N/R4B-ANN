﻿using System;
using System.Windows.Forms;

namespace pokazi_kaj_znas  // ← TVOJ NAMESPACE!
{
    // ═══════════════════════════════════════════════════════════════════════
    // DODAJ VOZILO FORM - dialog za dodajanje novega vozila
    // ═══════════════════════════════════════════════════════════════════════

    public partial class DodajVoziloForm : Form
    {
        // KONSTRUKTOR
        public DodajVoziloForm()
        {
            InitializeComponent();
        }


        // EVENT: Klik na gumb "Dodaj"
        private void btnDodaj_Click(object sender, EventArgs e)
        {
            // 1. VALIDACIJA - preveri, ali je lastnik vnešen
            if (string.IsNullOrWhiteSpace(txtLastnik.Text))
            {
                MessageBox.Show(
                    "Prosim vnesite lastnika vozila!",
                    "Napaka",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            // 2. POLIMORFIZEM - ustvari pravi tip vozila
            Vozilo novoVozilo;

            if (rbAvto.Checked)
            {
                novoVozilo = new Avto(txtLastnik.Text);
            }
            else if (rbMotor.Checked)
            {
                novoVozilo = new Motor(txtLastnik.Text);
            }
            else
            {
                MessageBox.Show(
                    "Prosim izberite tip vozila!",
                    "Napaka",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            // 3. DODAJ vozilo na parkirišče
            Parkirisce.DodajVozilo(novoVozilo);

            // 4. SPOROČILO
            MessageBox.Show(
                "Vozilo uspešno dodano!\n\n" +
                "Registrska: " + novoVozilo.Registrska + "\n" +
                "Lastnik: " + novoVozilo.Lastnik + "\n" +
                "Tip: " + (novoVozilo is Avto ? "🚗 Avto" : "🏍️ Motor"),
                "Uspeh",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );

            // 5. ZAPRI dialog
            this.DialogResult = DialogResult.OK;
            this.Close();
        }


        // EVENT: Klik na gumb "Prekliči"
        private void btnPreklici_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
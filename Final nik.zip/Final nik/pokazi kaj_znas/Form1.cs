﻿using System;
using System.Windows.Forms;

namespace pokazi_kaj_znas  // ← TVOJ NAMESPACE!
{
    // ═══════════════════════════════════════════════════════════════════════
    // FORM1 - glavno okno aplikacije
    // ═══════════════════════════════════════════════════════════════════════

    public partial class Form1 : Form
    {
        // KONSTRUKTOR
        public Form1()
        {
            InitializeComponent();
            OsveziSeznam();
        }


        // METODA: Osveži seznam vozil
        private void OsveziSeznam()
        {
            listBox1.Items.Clear();

            foreach (var vozilo in Parkirisce.PridobiVozila())
            {
                // POLIMORFIZEM - "is" preveri tip objekta
                string tip = vozilo is Avto ? "🚗 Avto" : "🏍️ Motor";

                // POLIMORFIZEM - kliče pravo metodo glede na tip
                decimal cena = vozilo.IzracunajCeno();

                string vrstica = vozilo.Registrska + " - " +
                                vozilo.Lastnik + " (" + tip + ") - " +
                                cena.ToString("F2") + "€";
                
                listBox1.Items.Add(vrstica);
            }

            label2.Text = "Vozil na parkirišču: " + Parkirisce.SteviloVozil();
        }


        // EVENT: Klik na gumb "Dodaj vozilo"
        private void btnDodaj_Click(object sender, EventArgs e)
        {
            DodajVoziloForm forma = new DodajVoziloForm();
            
            if (forma.ShowDialog() == DialogResult.OK)
            {
                OsveziSeznam();
            }
        }


        // EVENT: Klik na gumb "Osveži"
        private void btnOsvezi_Click(object sender, EventArgs e)
        {
            OsveziSeznam();
        }


        // EVENT: Klik na gumb "Odstrani"
        private void btnOdstrani_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                var vozilo = Parkirisce.PridobiVozila()[listBox1.SelectedIndex];
                
                DialogResult result = MessageBox.Show(
                    "Ali ste prepričani, da želite odstraniti vozilo " + 
                    vozilo.Registrska + "?",
                    "Potrditev",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.Yes)
                {
                    Parkirisce.OdstraniVozilo(vozilo);
                    OsveziSeznam();
                }
            }
            else
            {
                MessageBox.Show(
                    "Prosim izberite vozilo!",
                    "Napaka",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }
    }
}
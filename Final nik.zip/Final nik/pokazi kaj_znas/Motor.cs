﻿using System;

namespace pokazi_kaj_znas  // ← TVOJ NAMESPACE!
{
    // ═══════════════════════════════════════════════════════════════════════
    // MOTOR - tip vozila (deduje od Vozilo)
    // ═══════════════════════════════════════════════════════════════════════
    // OOP KONCEPTI:
    // ✅ DEDOVANJE - deduje vse od Vozilo
    // ✅ POLIMORFIZEM - override IzracunajCeno() DRUGAČE kot Avto
    // ═══════════════════════════════════════════════════════════════════════

    public class Motor : Vozilo
    {
        // KONSTRUKTOR
        public Motor(string lastnik) : base(lastnik)
        {
        }


        // OVERRIDE - Motor ima CENEJŠO parkiranje kot Avto
        public override decimal IzracunajCeno()
        {
            // Cena: 1€ na uro za motor
            TimeSpan cas = DateTime.Now - Ura;
            int ure = (int)Math.Ceiling(cas.TotalHours);
            return ure * 1m;
        }
    }
}
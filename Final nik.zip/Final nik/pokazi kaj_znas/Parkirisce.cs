﻿using System.Collections.Generic;

namespace pokazi_kaj_znas
{
    // ═══════════════════════════════════════════════════════════════════════
    // PARKIRIŠČE - statični razred za upravljanje vozil
    // ═══════════════════════════════════════════════════════════════════════
    // OOP KONCEPTI:
    // ✅ STATIC - globalni dostop brez instanciranja
    // ✅ ENKAPSULACIJA - privaten seznam, javne metode
    // ✅ COLLECTIONS - List<Vozilo> za shranjevanje
    // ═══════════════════════════════════════════════════════════════════════

    public static class Parkirisce
    {
        // ENKAPSULACIJA - privaten seznam
        private static List<Vozilo> _vozila = new List<Vozilo>();


        // METODA: Dodaj vozilo
        public static void DodajVozilo(Vozilo vozilo)
        {
            _vozila.Add(vozilo);
        }


        // METODA: Odstrani vozilo
        public static void OdstraniVozilo(Vozilo vozilo)
        {
            _vozila.Remove(vozilo);
        }


        // METODA: Pridobi VSA vozila
        public static List<Vozilo> PridobiVozila()
        {
            return _vozila;
        }


        // METODA: Število vozil
        public static int SteviloVozil()
        {
            return _vozila.Count;
        }
    }
}
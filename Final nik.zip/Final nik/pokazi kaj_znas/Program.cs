﻿
using System;
using System.Windows.Forms;

namespace pokazi_kaj_znas  // ← POMEMBNO: Tvoj namespace!
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());  // Odpre Form1 ob zagonu
        }
    }
}
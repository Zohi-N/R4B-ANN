﻿using System;

namespace pokazi_kaj_znas
{
    // ═══════════════════════════════════════════════════════════════════════
    // VOZILO - abstraktni razred (starš za Avto in Motor)
    // ═══════════════════════════════════════════════════════════════════════
    // OOP KONCEPTI:
    // ✅ ABSTRACT - ne moreš narediti "new Vozilo()", samo Avto/Motor
    // ✅ ENKAPSULACIJA - properties s get/private set
    // ✅ POLIMORFIZEM - abstract metoda IzracunajCeno()
    // ═══════════════════════════════════════════════════════════════════════

    public abstract class Vozilo
    {
        // ENKAPSULACIJA - private set (samo internal lahko spreminja)
        public string Registrska { get; private set; }
        public string Lastnik { get; private set; }
        public DateTime Ura { get; private set; }

        // STATIC - števec za generiranje registrskih
        private static int _stevilka = 1000;


        // KONSTRUKTOR
        protected Vozilo(string lastnik)
        {
            Lastnik = lastnik;
            Registrska = "LJ-" + _stevilka++;
            Ura = DateTime.Now;
        }


        // ABSTRACT METODA - vsak tip vozila MORA implementirati
        // POLIMORFIZEM: Avto in Motor imata SVOJO verzijo te metode
        public abstract decimal IzracunajCeno();
    }
}